﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using AbleWarsStatistics.Models;

namespace AbleWarsStatistics.Controllers
{
    public class StatisticsController : Controller
    {
        //private AbleWarsModel db = new AbleWarsModel();
        IRepository<StatisticViewModel> repo;

        public StatisticsController() : this(new StatisticsRepository())
        {
        }

        public StatisticsController(IRepository<StatisticViewModel> _repo)
        {
            this.repo = _repo;
        }

        // GET: Statistics
        public ActionResult Index()
        {
            var statistics = repo.Get();
            return View(statistics);
        }

        public ActionResult StatsByNumOfGames()
        {
            var statistics = repo.Get();
            statistics = SortStatsByGames(statistics);
            return View(statistics);
        }

        public ActionResult StatsByNumOfWins()
        {
            var statistics = repo.Get();
            statistics = SortStatsByWins(statistics);
            return View(statistics);
        }

        public ActionResult StatsByWinRatio()
        {
            var statistics = repo.Get();
            statistics = SortStatsByWinRatio(statistics);
            return View(statistics);
        }

        public ActionResult StatsByFastestWin()
        {
            var statistics = repo.Get();
            statistics = SortStatsByFastestWin(statistics);
            return View(statistics);
        }

        public ActionResult StatsByHighestScore()
        {
            var statistics = repo.Get();
            statistics = SortStatsByHighestScore(statistics);
            return View(statistics);
        }

        public ICollection<StatisticViewModel> SortStatsByGames(ICollection<StatisticViewModel> stats)
        {
            List<StatisticViewModel> sortedStats = new List<StatisticViewModel>();
            foreach (StatisticViewModel stat in stats)
            {
                if (sortedStats.Count == 0)
                {
                    sortedStats.Add(stat);
                }
                else
                {
                    int i = 0;
                    while (i < sortedStats.Count && stat.gamesPlayed <= sortedStats[i].gamesPlayed)
                    {
                        i++;
                    }
                    sortedStats.Insert(i, stat);
                }
            }
            return sortedStats;
        }

        public ICollection<StatisticViewModel> SortStatsByWins(ICollection<StatisticViewModel> stats)
        {
            List<StatisticViewModel> sortedStats = new List<StatisticViewModel>();
            foreach (StatisticViewModel stat in stats)
            {
                if (sortedStats.Count == 0)
                {
                    sortedStats.Add(stat);
                }
                else
                {
                    int i = 0;
                    while (i < sortedStats.Count && stat.wins <= sortedStats[i].wins)
                    {
                        i++;
                    }
                    sortedStats.Insert(i, stat);
                }
            }
            return sortedStats;
        }

        public ICollection<StatisticViewModel> SortStatsByWinRatio(ICollection<StatisticViewModel> stats)
        {
            List<StatisticViewModel> sortedStats = new List<StatisticViewModel>();
            foreach (StatisticViewModel stat in stats)
            {
                if (sortedStats.Count == 0 || stat.gamesPlayed <= 0)
                {
                    sortedStats.Add(stat);
                }
                else
                {
                    int i = 0;
                    while (i < sortedStats.Count && stat.winRatio <= sortedStats[i].winRatio)
                    {
                        i++;
                    }
                    sortedStats.Insert(i, stat);
                }
            }
            return sortedStats;
        }

        public ICollection<StatisticViewModel> SortStatsByFastestWin(ICollection<StatisticViewModel> stats)
        {
            List<StatisticViewModel> sortedStats = new List<StatisticViewModel>();
            foreach (StatisticViewModel stat in stats)
            {
                if (sortedStats.Count == 0 || stat.gamesPlayed <= 0)
                {
                    sortedStats.Add(stat);
                }
                else
                {
                    int i = 0;
                    while (i < sortedStats.Count && sortedStats[i].gamesPlayed > 0 && stat.fastestWin >= sortedStats[i].fastestWin)
                    {
                        i++;
                    }
                    sortedStats.Insert(i, stat);
                }
            }
            return sortedStats;
        }

        public ICollection<StatisticViewModel> SortStatsByHighestScore(ICollection<StatisticViewModel> stats)
        {
            List<StatisticViewModel> sortedStats = new List<StatisticViewModel>();
            foreach (StatisticViewModel stat in stats)
            {
                if (sortedStats.Count == 0)
                {
                    sortedStats.Add(stat);
                }
                else
                {
                    int i = 0;
                    while (i < sortedStats.Count && stat.highestScore <= sortedStats[i].highestScore)
                    {
                        i++;
                    }
                    sortedStats.Insert(i, stat);
                }
            }
            return sortedStats;
        }

        // GET: Statistics/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            StatisticViewModel statistic = repo.Get(id);
            if (statistic == null)
            {
                return HttpNotFound();
            }
            return View(statistic);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
