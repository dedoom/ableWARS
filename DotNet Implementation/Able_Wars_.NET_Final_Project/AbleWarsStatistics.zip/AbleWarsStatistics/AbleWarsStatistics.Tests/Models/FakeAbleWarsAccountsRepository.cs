﻿using AbleWarsStatistics.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbleWarsStatistics.Tests.Models
{
    class FakeAbleWarsAccountsRepository : IRepository<account>
    {
        public static readonly int NumOfAbleWarsAccounts = 50;
        private readonly int NumOfTeams = 10;

        public ICollection<account> Get()
        {
            ICollection<account> accounts = new List<account>();
            for (int i = 0; i < NumOfAbleWarsAccounts; i++)
            {
                account account = Get(i.ToString());
                accounts.Add(account);
            }
            return accounts;
        }

        public account Get(string id)
        {
            account account = new account()
            {
                username = "User" + id,
                fname = "First" + id,
                lname = "Last" + id,
                password = "Password" + id
            };
            if (Int32.Parse(id) > 0)
            {
                account.teamid = "Team" + (NumOfTeams % Int32.Parse(id));
            }
            else
            {
                account.teamid = "Team" + 0;
            }
            return account;
        }

        public account Get(int? id)
        {
            throw new NotImplementedException();
        }

        public void Post(account model)
        {
            return;
        }

        public void Put(account model)
        {
            return;
        }

        public void Delete(string id)
        {
            return;
        }

        public void Delete(int? id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<account> GetQueryable()
        {
            ICollection<account> accounts = new List<account>();
            for (int i = 0; i < NumOfAbleWarsAccounts; i++)
            {
                account account = Get(i.ToString());
                accounts.Add(account);
            }
            return accounts.AsQueryable();
        }
    }
}
