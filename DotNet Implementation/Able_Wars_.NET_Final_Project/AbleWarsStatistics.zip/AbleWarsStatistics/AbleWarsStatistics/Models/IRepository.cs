﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbleWarsStatistics.Models
{
    public interface IRepository<T>
    {
        ICollection<T> Get();

        T Get(int? id);

        T Get(string id);

        IQueryable<T> GetQueryable();

        void Post(T model);

        void Put(T model);

        void Delete(int? id);

        void Delete(string id);
    }
}
