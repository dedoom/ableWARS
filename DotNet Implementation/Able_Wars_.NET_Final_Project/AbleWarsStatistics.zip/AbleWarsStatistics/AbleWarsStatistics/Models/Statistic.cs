namespace AbleWarsStatistics.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Statistic
    {
        [Key]
        public int accountStatistics { get; set; }

        [Required]
        [StringLength(30)]
        public string username { get; set; }

        public int wins { get; set; }

        public int losses { get; set; }

        public int? fastestWin { get; set; }

        public int? highestScore { get; set; }

        public int gamesPlayed { get; set; }

        public virtual account account { get; set; }
    }
}
