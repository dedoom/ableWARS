﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AbleWarsStatistics.Controllers;
using AbleWarsStatistics.Tests.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using AbleWarsStatistics.Models;

namespace AbleWarsStatistics.Tests.Controllers
{
    [TestClass]
    public class AbleWarsAccountsControllerUnitTest
    {
        [TestMethod]
        public void IndexTest()
        {
            //Arrange
            AbleWarsAccountsController controller = new AbleWarsAccountsController(new FakeAbleWarsAccountsRepository());

            //Act
            ActionResult actionResult = controller.Index() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<account> accountModelCollection = viewResult.Model as List<account>;
            account firstAccountModel = accountModelCollection[0] as account;
            string firstAccountModelUsername = firstAccountModel.username;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(accountModelCollection);
            Assert.AreEqual(FakeAbleWarsAccountsRepository.NumOfAbleWarsAccounts, accountModelCollection.Count);
            Assert.IsNotNull(firstAccountModel);
            Assert.IsNotNull(firstAccountModelUsername);
            Assert.AreEqual("User0", firstAccountModelUsername);
        }

        [TestMethod]
        public void DetailsTest()
        {
            //Arrange
            AbleWarsAccountsController controller = new AbleWarsAccountsController(new FakeAbleWarsAccountsRepository());

            //Act
            ActionResult actionResult = controller.Details("0") as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            account accountModel = viewResult.Model as account;
            string accountModelUsername = accountModel.username;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(accountModel);
            Assert.IsNotNull(accountModelUsername);
            Assert.AreEqual("User0", accountModelUsername);
        }

        [TestMethod]
        public void PostTest()
        {
            //Arrange
            FakeAbleWarsAccountsRepository repo = new FakeAbleWarsAccountsRepository();
            AbleWarsAccountsController controller = new AbleWarsAccountsController(repo);
            account account = repo.Get("0");

            //Act
            ActionResult actionResult = controller.Create() as ActionResult;
            RedirectToRouteResult redirectResult = controller.Create(account) as RedirectToRouteResult;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(redirectResult);
            Assert.IsTrue(redirectResult.RouteValues.ContainsKey("action"));
            Assert.AreEqual("Index", redirectResult.RouteValues["action"]);
        }

        [TestMethod]
        public void PutTest()
        {
            //Arrange
            FakeAbleWarsAccountsRepository repo = new FakeAbleWarsAccountsRepository();
            AbleWarsAccountsController controller = new AbleWarsAccountsController(repo);

            //Act
            ActionResult actionResult = controller.Edit("0") as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            account accountModel = viewResult.Model as account;
            accountModel.username = "New" + accountModel.username;
            accountModel.password = "New" + accountModel.password;
            RedirectToRouteResult rediectResult = controller.Edit(accountModel) as RedirectToRouteResult;


            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(accountModel);
            Assert.AreEqual("NewUser0", accountModel.username);
            Assert.AreEqual("NewPassword0", accountModel.password);
            Assert.IsNotNull(rediectResult);
            Assert.IsTrue(rediectResult.RouteValues.ContainsKey("action"));
            Assert.AreEqual("Index", rediectResult.RouteValues["action"]);
        }

        [TestMethod]
        public void DeleteTest()
        {
            //Arrange
            FakeAbleWarsAccountsRepository repo = new FakeAbleWarsAccountsRepository();
            AbleWarsAccountsController controller = new AbleWarsAccountsController(repo);

            //Act
            ActionResult actionResult = controller.Delete("0") as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            account accountModel = viewResult.Model as account;
            string accountModelUsername = accountModel.username;
            RedirectToRouteResult redirectResult = controller.DeleteConfirmed(accountModelUsername) as RedirectToRouteResult;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(accountModel);
            Assert.IsNotNull(accountModelUsername);
            Assert.AreEqual("User0", accountModelUsername);
            Assert.IsNotNull(redirectResult);
            Assert.IsTrue(redirectResult.RouteValues.ContainsKey("action"));
            Assert.AreEqual("Index", redirectResult.RouteValues["action"]);
        }
    }
}
