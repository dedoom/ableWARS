﻿using AbleWarsStatistics.Controllers;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Http.Results;
using System.Web.Mvc;

namespace AbleWarsStatistics.Models
{
    public class AbleWarsAccountsRepository : IRepository<account>
    {
        //private AbleWarsModel db = new AbleWarsModel();
        AbleWarsAccountsAPIController apiController = new AbleWarsAccountsAPIController();

        public ICollection<account> Get()
        {
            return apiController.accountsNonQueryable();
        }

        public account Get(int? id)
        {
            throw new NotImplementedException();
        }

        public account Get(string id)
        {
            OkNegotiatedContentResult<account> result = apiController.Getaccount(id) as OkNegotiatedContentResult<account>;
            return result.Content;
        }

        public void Post(account ableWarsAccount)
        {
            apiController.Postaccount(ableWarsAccount);
        }

        public void Put(account ableWarsAccount)
        {
            apiController.Putaccount(ableWarsAccount.username, ableWarsAccount);
        }

        public void Delete(int? id)
        {
            throw new NotImplementedException();
        }

        public void Delete(string id)
        {
            apiController.Deleteaccount(id);
        }

        public IQueryable<account> GetQueryable()
        {
            throw new NotImplementedException();
        }
    }
}