﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AbleWarsStatistics.Models
{
    public class StatisticViewModel : Controller
    {
        public int accountStatistics { get; set; }

        public string username { get; set; }

        public int wins { get; set; }

        public int losses { get; set; }

        public float winRatio { get; set; }

        public int? fastestWin { get; set; }

        public int? highestScore { get; set; }

        public int gamesPlayed { get; set; }
    }
}