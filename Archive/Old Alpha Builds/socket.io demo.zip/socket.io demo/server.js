//socket io server side setup/instantiation
var express = require('express'),
	app = express(),
	server = require('http').Server(app),
	io = require('socket.io').listen(server),
	path = require('path');

app.use(express.static(path.join(__dirname + '/')));
	
app.get('/', function(req, res){
	res.sendFile(__dirname + '/index.html');
});
	
io.on('connection', function(socket){
	console.log("connection detected");
	
	socket.on('btnPress', function(timestamp){
		console.log("server received emited btnPress");
		io.emit('btnPress', timestamp);
		console.log("server emited btnPress to client(s)");
	});
});

server.listen(4000, function(){
	console.log("listening on port 4000");
});