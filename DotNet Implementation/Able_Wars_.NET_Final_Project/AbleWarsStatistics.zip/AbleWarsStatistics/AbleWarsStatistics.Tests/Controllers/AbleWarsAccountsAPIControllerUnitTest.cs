﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AbleWarsStatistics.Controllers;
using AbleWarsStatistics.Tests.Models;
using System.Collections.Generic;
using AbleWarsStatistics.Models;
using System.Web.Http.Results;
using System.Linq;

namespace AbleWarsStatistics.Tests.Controllers
{
    [TestClass]
    public class AbleWarsAccountsAPIControllerUnitTest
    {
        [TestMethod]
        public void GetaccountsTest()
        {
            //Arrange
            AbleWarsAccountsAPIController controller = new AbleWarsAccountsAPIController(new FakeAbleWarsAccountsRepository());

            //Act
            /*IQueryable<account> accountsCollection = controller.Getaccounts() as IQueryable<account>;
            List<account> accountList = accountsCollection.AsEnumerable() as List<account>;*/
            List<account> accountsCollection = controller.accountsNonQueryable() as List<account>;
            account firstAccount = accountsCollection[0];

            //Assert
            Assert.IsNotNull(accountsCollection);
            //Assert.IsNotNull(accountList);
            Assert.IsNotNull(firstAccount);
        }

        [TestMethod]
        public void GetaccountTest()
        {
            //Arrange
            AbleWarsAccountsAPIController controller = new AbleWarsAccountsAPIController(new FakeAbleWarsAccountsRepository());

            //Act
            OkNegotiatedContentResult<account> okResult = controller.Getaccount("0") as OkNegotiatedContentResult<account>;
            account account = okResult.Content;
            string accountUsername = account.username;

            //Assert
            Assert.IsNotNull(okResult);
            Assert.IsNotNull(account);
            Assert.IsNotNull(accountUsername);
            Assert.AreEqual("User0", accountUsername);
        }

        [TestMethod]
        public void PutaccountTest()
        {
            //Arrange
            FakeAbleWarsAccountsRepository repo = new FakeAbleWarsAccountsRepository();
            AbleWarsAccountsAPIController controller = new AbleWarsAccountsAPIController(repo);
            account account = repo.Get("0");

            //Act
            StatusCodeResult statusResult = controller.Putaccount(account.username, account) as StatusCodeResult;

            //Assert
            Assert.IsNotNull(statusResult);
        }

        [TestMethod]
        public void PostaccountTest()
        {
            //Arrange
            FakeAbleWarsAccountsRepository repo = new FakeAbleWarsAccountsRepository();
            AbleWarsAccountsAPIController controller = new AbleWarsAccountsAPIController(repo);
            account account = repo.Get("0");

            //Act
            CreatedAtRouteNegotiatedContentResult<account> createdResult = controller.Postaccount(account) as CreatedAtRouteNegotiatedContentResult<account>;
            account createdAccount = createdResult.Content;
            string createdAccountUsername = createdAccount.username;

            //Assert
            Assert.IsNotNull(createdResult);
            Assert.IsNotNull(createdAccount);
            Assert.IsNotNull(createdAccountUsername);
            Assert.AreEqual("User0", createdAccountUsername);
        }

        [TestMethod]
        public void DeleteaccountTest()
        {
            //Arrange
            AbleWarsAccountsAPIController controller = new AbleWarsAccountsAPIController(new FakeAbleWarsAccountsRepository());

            //Act
            OkNegotiatedContentResult<account> okResult = controller.Deleteaccount("0") as OkNegotiatedContentResult<account>;
            account account = okResult.Content;
            string accountUsername = account.username;

            //Assert
            Assert.IsNotNull(okResult);
            Assert.IsNotNull(account);
            Assert.IsNotNull(accountUsername);
            Assert.AreEqual("User0", accountUsername);
        }
    }
}
