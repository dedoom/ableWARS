﻿using AbleWarsStatistics.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbleWarsStatistics.Tests.Models
{
    class FakeStatisticsRepository : IRepository<StatisticViewModel>
    {
        public static readonly int NumOfStats = 50;
        private readonly int HighestPossibleScore = 10;
        private readonly int MatchTimeLimit = 60;

        public ICollection<StatisticViewModel> Get()
        {
            ICollection<StatisticViewModel> statistics = new List<StatisticViewModel>();
            for (int i = 0; i < NumOfStats; i++)
            {
                StatisticViewModel newStat = Get(i);
                statistics.Add(newStat);
            }
            return statistics;
        }

        public StatisticViewModel Get(string id)
        {
            throw new NotImplementedException();
        }

        public StatisticViewModel Get(int? id)
        {
            StatisticViewModel newStat = new StatisticViewModel()
            {
                gamesPlayed = new Random().Next(),
                highestScore = new Random().Next(HighestPossibleScore),
                accountStatistics = (int)id,
                username = "User" + (int)id
            };
            newStat.wins = new Random().Next(newStat.gamesPlayed);
            newStat.losses = newStat.gamesPlayed - newStat.wins;
            newStat.winRatio = (float)newStat.wins / (float)newStat.gamesPlayed;
            if (newStat.wins > 0)
            {
                newStat.fastestWin = new Random().Next(MatchTimeLimit);
            }
            else
            {
                newStat.fastestWin = 0;
            }
            return newStat;
        }

        public void Post(StatisticViewModel model)
        {
            throw new NotImplementedException();
        }

        public void Put(StatisticViewModel model)
        {
            throw new NotImplementedException();
        }

        public void Delete(string id)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<StatisticViewModel> GetQueryable()
        {
            throw new NotImplementedException();
        }
    }
}
