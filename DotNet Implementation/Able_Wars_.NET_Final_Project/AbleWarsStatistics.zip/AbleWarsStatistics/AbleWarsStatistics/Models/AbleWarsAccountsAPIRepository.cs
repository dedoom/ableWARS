﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AbleWarsStatistics.Models
{
    public class AbleWarsAccountsAPIRepository : IRepository<account>
    {
        private AbleWarsModel db = new AbleWarsModel();

        public ICollection<account> Get()
        {
            return db.accounts.ToList();
        }

        public IQueryable<account> GetQueryable()
        {
            return db.accounts;
        }

        public account Get(string id)
        {
            return db.accounts.Find(id);
        }

        public account Get(int? id)
        {
            throw new NotImplementedException();
        }

        public void Post(account account)
        {
            db.accounts.Add(account);
            db.SaveChanges();
        }

        public void Put(account account)
        {
            db.Entry(account).State = EntityState.Modified;
            db.SaveChanges();
        }

        public void Delete(string id)
        {
            account account = Get(id);
            db.accounts.Remove(account);
            db.SaveChanges();
        }

        public void Delete(int? id)
        {
            throw new NotImplementedException();
        }
    }
}