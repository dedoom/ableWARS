﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using AbleWarsStatistics.Models;

namespace AbleWarsStatistics.Controllers
{
    [Authorize(Roles = "Admin")]
    public class AbleWarsAccountsAPIController : ApiController
    {
        //private AbleWarsModel db = new AbleWarsModel();
        IRepository<account> repo;

        /// <summary>
        /// Default constructor initializes default IRepository as an AbleWarsAccountRepository
        /// </summary>
        // Default Constructor
        public AbleWarsAccountsAPIController() : this(new AbleWarsAccountsAPIRepository())
        {
        }

        /// <summary>
        /// Constructor sets repo to a given instance of an IRepository
        /// </summary>
        /// <param name="_repo"></param>
        // Overloaded Constructor
        public AbleWarsAccountsAPIController(IRepository<account> _repo)
        {
            this.repo = _repo;
        }

        /// <summary>
        /// Returns an IQueryable from repo
        /// </summary>
        /// <returns></returns>
        // GET: api/AbleWarsAccountsAPI
        public IQueryable<account> Getaccounts()
        {
            return repo.GetQueryable();
        }

        /// <summary>
        /// Returns an ICollection from repo
        /// </summary>
        /// <returns></returns>
        public ICollection<account> accountsNonQueryable()
        {
            return repo.Get();
        }

        /// <summary>
        /// Returns an account with the username matching the given id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ResponseType(typeof(account))]
        public IHttpActionResult Getaccount(string id)
        {
            account account = repo.Get(id);
            if (account == null)
            {
                return NotFound();
            }

            return Ok(account);
        }

        // PUT: api/AbleWarsAccountsAPI/5
        /// <summary>
        /// Alters an existing account with a username matching the given id, to represent the given account model
        /// </summary>
        /// <param name="id"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        [ResponseType(typeof(void))]
        public IHttpActionResult Putaccount(string id, account account)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != account.username)
            {
                return BadRequest();
            }


            try
            {
                repo.Put(account);
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!accountExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/AbleWarsAccountsAPI
        /// <summary>
        /// Creates a new account representing the given account model
        /// </summary>
        /// <param name="account"></param>
        /// <returns></returns>
        [ResponseType(typeof(account))]
        public IHttpActionResult Postaccount(account account)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                repo.Post(account);
            }
            catch (DbUpdateException)
            {
                if (accountExists(account.username))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = account.username }, account);
        }

        // DELETE: api/AbleWarsAccountsAPI/5
        /// <summary>
        /// Deletes the account which has a username which matches the given id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [ResponseType(typeof(account))]
        public IHttpActionResult Deleteaccount(string id)
        {
            account account = repo.Get(id);
            if (account == null)
            {
                return NotFound();
            }

            repo.Delete(id);

            return Ok(account);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                //db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool accountExists(string id)
        {
            return null != repo.Get(id);
        }
    }
}