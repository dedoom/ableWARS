﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AbleWarsStatistics.Models
{
    public class StatisticsRepository : IRepository<StatisticViewModel>
    {
        private AbleWarsModel db = new AbleWarsModel();

        public ICollection<StatisticViewModel> Get()
        {
            ICollection<Statistic> statistics = db.Statistics.ToList();
            ICollection<StatisticViewModel> statViewModels = new List<StatisticViewModel>();
            foreach (Statistic stat in statistics)
            {
                float statWinRatio = (float)stat.wins / (float)stat.gamesPlayed;
                statViewModels.Add(new StatisticViewModel()
                {
                    accountStatistics = stat.accountStatistics,
                    username = stat.username,
                    wins = stat.wins,
                    losses = stat.losses,
                    winRatio = statWinRatio,
                    fastestWin = stat.fastestWin,
                    highestScore = stat.highestScore,
                    gamesPlayed = stat.gamesPlayed
                });
            }
            return statViewModels;
        }

        public StatisticViewModel Get(int? id)
        {
            Statistic stat = db.Statistics.Find(id);
            float statWinRatio = (float)stat.wins / (float)stat.gamesPlayed;
            return new StatisticViewModel()
            {
                accountStatistics = stat.accountStatistics,
                username = stat.username,
                wins = stat.wins,
                losses = stat.losses,
                winRatio = statWinRatio,
                fastestWin = stat.fastestWin,
                highestScore = stat.highestScore,
                gamesPlayed = stat.gamesPlayed
            };
        }

        public StatisticViewModel Get(string id)
        {
            throw new NotImplementedException();
        }

        public void Post(StatisticViewModel stat)
        {
            throw new NotImplementedException();
        }

        public void Put(StatisticViewModel stat)
        {
            throw new NotImplementedException();
        }

        public void Delete(int? id)
        {
            throw new NotImplementedException();
        }

        public void Delete(string id)
        {
            throw new NotImplementedException();
        }

        public IQueryable<StatisticViewModel> GetQueryable()
        {
            throw new NotImplementedException();
        }
    }
}