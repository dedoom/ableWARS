namespace AbleWarsStatistics.Models
{
    using System;
    using System.Data.Entity;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Linq;

    public partial class AbleWarsModel : DbContext
    {
        public AbleWarsModel()
            : base("name=AbleWars_Model")
        {
        }

        public virtual DbSet<account> accounts { get; set; }
        public virtual DbSet<Statistic> Statistics { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<account>()
                .Property(e => e.username)
                .IsUnicode(false);

            modelBuilder.Entity<account>()
                .Property(e => e.fname)
                .IsUnicode(false);

            modelBuilder.Entity<account>()
                .Property(e => e.lname)
                .IsUnicode(false);

            modelBuilder.Entity<account>()
                .Property(e => e.password)
                .IsUnicode(false);

            modelBuilder.Entity<account>()
                .Property(e => e.teamid)
                .IsUnicode(false);

            modelBuilder.Entity<account>()
                .HasMany(e => e.Statistics)
                .WithRequired(e => e.account)
                .WillCascadeOnDelete(false);

            modelBuilder.Entity<Statistic>()
                .Property(e => e.username)
                .IsUnicode(false);
        }
    }
}
