﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AbleWarsStatistics.Controllers;
using AbleWarsStatistics.Tests.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using AbleWarsStatistics.Models;

namespace AbleWarsStatistics.Tests.Controllers
{
    [TestClass]
    public class StatisticsControllerUnitTest
    {
        [TestMethod]
        public void IndexTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.Index() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<StatisticViewModel> modelCollection = viewResult.Model as List<StatisticViewModel>;
            StatisticViewModel firstStat = modelCollection[0] as StatisticViewModel;
            int firstStatID = firstStat.accountStatistics;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(modelCollection);
            Assert.AreEqual(FakeStatisticsRepository.NumOfStats, modelCollection.Count);
            Assert.IsNotNull(firstStat);
            Assert.IsNotNull(firstStatID);
            Assert.AreEqual(0, firstStatID);
        }

        [TestMethod]
        public void StatsByNumOfGamesTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.StatsByNumOfGames() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<StatisticViewModel> modelCollection = viewResult.Model as List<StatisticViewModel>;
            StatisticViewModel firstStat = modelCollection[0] as StatisticViewModel;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(modelCollection);
            Assert.AreEqual(FakeStatisticsRepository.NumOfStats, modelCollection.Count);
            Assert.IsNotNull(firstStat);
        }

        [TestMethod]
        public void StatsByNumOfWinsTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.StatsByNumOfWins() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<StatisticViewModel> modelCollection = viewResult.Model as List<StatisticViewModel>;
            StatisticViewModel firstStat = modelCollection[0] as StatisticViewModel;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(modelCollection);
            Assert.AreEqual(FakeStatisticsRepository.NumOfStats, modelCollection.Count);
            Assert.IsNotNull(firstStat);
        }

        [TestMethod]
        public void StatsByWinRatioTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.StatsByWinRatio() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<StatisticViewModel> modelCollection = viewResult.Model as List<StatisticViewModel>;
            StatisticViewModel firstStat = modelCollection[0] as StatisticViewModel;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(modelCollection);
            Assert.AreEqual(FakeStatisticsRepository.NumOfStats, modelCollection.Count);
            Assert.IsNotNull(firstStat);
        }

        [TestMethod]
        public void StatsByFastestWinTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.StatsByFastestWin() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<StatisticViewModel> modelCollection = viewResult.Model as List<StatisticViewModel>;
            StatisticViewModel firstStat = modelCollection[0] as StatisticViewModel;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(modelCollection);
            Assert.AreEqual(FakeStatisticsRepository.NumOfStats, modelCollection.Count);
            Assert.IsNotNull(firstStat);
        }

        [TestMethod]
        public void StatsByHighestScoreTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.StatsByHighestScore() as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            List<StatisticViewModel> modelCollection = viewResult.Model as List<StatisticViewModel>;
            StatisticViewModel firstStat = modelCollection[0] as StatisticViewModel;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(modelCollection);
            Assert.AreEqual(FakeStatisticsRepository.NumOfStats, modelCollection.Count);
            Assert.IsNotNull(firstStat);
        }

        [TestMethod]
        public void SortStatsByGamesTest()
        {
            //Arrange
            FakeStatisticsRepository repo = new FakeStatisticsRepository();
            StatisticsController controller = new StatisticsController(repo);
            List<StatisticViewModel> statistics = repo.Get() as List<StatisticViewModel>;

            //Act
            List<StatisticViewModel> sortedStats = controller.SortStatsByGames(statistics) as List<StatisticViewModel>;

            //Assert
            foreach (StatisticViewModel statistic in statistics)
            {
                bool found = false;
                foreach (StatisticViewModel sortedStat in sortedStats)
                {
                    if (statistic.username.Equals(sortedStat.username))
                    {
                        found = true;
                        break;
                    }
                }
                Assert.AreEqual(true, found);
            }
            for (var i = 0; i < sortedStats.Count; i++)
            {
                if (i > 0)
                {
                    Assert.IsTrue(sortedStats[i].gamesPlayed <= sortedStats[i - 1].gamesPlayed);
                }
                if (i < sortedStats.Count - 1)
                {
                    Assert.IsTrue(sortedStats[i].gamesPlayed >= sortedStats[i + 1].gamesPlayed);
                }
            }
        }

        [TestMethod]
        public void SortStatsByWinsTest()
        {
            //Arrange
            FakeStatisticsRepository repo = new FakeStatisticsRepository();
            StatisticsController controller = new StatisticsController(repo);
            List<StatisticViewModel> statistics = repo.Get() as List<StatisticViewModel>;

            //Act
            List<StatisticViewModel> sortedStats = controller.SortStatsByWins(statistics) as List<StatisticViewModel>;

            //Assert
            foreach (StatisticViewModel statistic in statistics)
            {
                bool found = false;
                foreach (StatisticViewModel sortedStat in sortedStats)
                {
                    if (statistic.username.Equals(sortedStat.username))
                    {
                        found = true;
                        break;
                    }
                }
                Assert.AreEqual(true, found);
            }
            for (var i = 0; i < sortedStats.Count; i++)
            {
                if (i > 0)
                {
                    Assert.IsTrue(sortedStats[i].wins <= sortedStats[i - 1].wins);
                }
                if (i < sortedStats.Count - 1)
                {
                    Assert.IsTrue(sortedStats[i].wins >= sortedStats[i + 1].wins);
                }
            }
        }

        [TestMethod]
        public void SortStatsByWinRatioTest()
        {
            //Arrange
            FakeStatisticsRepository repo = new FakeStatisticsRepository();
            StatisticsController controller = new StatisticsController(repo);
            List<StatisticViewModel> statistics = repo.Get() as List<StatisticViewModel>;

            //Act
            List<StatisticViewModel> sortedStats = controller.SortStatsByWinRatio(statistics) as List<StatisticViewModel>;

            //Assert
            foreach (StatisticViewModel statistic in statistics)
            {
                bool found = false;
                foreach (StatisticViewModel sortedStat in sortedStats)
                {
                    if (statistic.username.Equals(sortedStat.username))
                    {
                        found = true;
                        break;
                    }
                }
                Assert.AreEqual(true, found);
            }
            for (var i = 0; i < sortedStats.Count; i++)
            {
                if (i > 0)
                {
                    Assert.IsTrue(sortedStats[i].winRatio <= sortedStats[i - 1].winRatio);
                }
                if (i < sortedStats.Count - 1)
                {
                    Assert.IsTrue(sortedStats[i].winRatio >= sortedStats[i + 1].winRatio);
                }
            }
        }

        [TestMethod]
        public void SortStatsByFastestWinTest()
        {
            //Arrange
            FakeStatisticsRepository repo = new FakeStatisticsRepository();
            StatisticsController controller = new StatisticsController(repo);
            List<StatisticViewModel> statistics = repo.Get() as List<StatisticViewModel>;

            //Act
            List<StatisticViewModel> sortedStats = controller.SortStatsByFastestWin(statistics) as List<StatisticViewModel>;

            //Assert
            foreach (StatisticViewModel statistic in statistics)
            {
                bool found = false;
                foreach (StatisticViewModel sortedStat in sortedStats)
                {
                    if (statistic.username.Equals(sortedStat.username))
                    {
                        found = true;
                        break;
                    }
                }
                Assert.AreEqual(true, found);
            }
            for (var i = 0; i < sortedStats.Count; i++)
            {
                if (i > 0 && !(sortedStats[i - 1].gamesPlayed > 0 && sortedStats[i].gamesPlayed == 0))
                {
                    Assert.IsTrue(sortedStats[i].fastestWin >= sortedStats[i - 1].fastestWin);
                }
                if (i < sortedStats.Count - 1 && !(sortedStats[i].gamesPlayed > 0 && sortedStats[i + 1].gamesPlayed == 0))
                {
                    Assert.IsTrue(sortedStats[i].fastestWin <= sortedStats[i + 1].fastestWin);
                }
            }
        }

        [TestMethod]
        public void SortStatsByHighestScoreTest()
        {
            //Arrange
            FakeStatisticsRepository repo = new FakeStatisticsRepository();
            StatisticsController controller = new StatisticsController(repo);
            List<StatisticViewModel> statistics = repo.Get() as List<StatisticViewModel>;

            //Act
            List<StatisticViewModel> sortedStats = controller.SortStatsByHighestScore(statistics) as List<StatisticViewModel>;

            //Assert
            foreach (StatisticViewModel statistic in statistics)
            {
                bool found = false;
                foreach (StatisticViewModel sortedStat in sortedStats)
                {
                    if (statistic.username.Equals(sortedStat.username))
                    {
                        found = true;
                        break;
                    }
                }
                Assert.AreEqual(true, found);
            }
            for (var i = 0; i < sortedStats.Count; i++)
            {
                if (i > 0)
                {
                    Assert.IsTrue(sortedStats[i].highestScore <= sortedStats[i - 1].highestScore);
                }
                if (i < sortedStats.Count - 1)
                {
                    Assert.IsTrue(sortedStats[i].highestScore >= sortedStats[i + 1].highestScore);
                }
            }
        }

        [TestMethod]
        public void DetailsTest()
        {
            //Arrange
            StatisticsController controller = new StatisticsController(new FakeStatisticsRepository());

            //Act
            ActionResult actionResult = controller.Details(0) as ActionResult;
            ViewResult viewResult = actionResult as ViewResult;
            StatisticViewModel statisticModel = viewResult.Model as StatisticViewModel;
            int statisticModelID = statisticModel.accountStatistics;

            //Assert
            Assert.IsNotNull(actionResult);
            Assert.IsNotNull(viewResult);
            Assert.IsNotNull(statisticModel);
            Assert.IsNotNull(statisticModelID);
            Assert.AreEqual(0, statisticModelID);
        }
    }
}
