// client side socket.io script

/*var socket = io.connect("http://localhost:4000")

function btnPress() {
	var timestamp = Date.now();
		
	socket.emit('btnPress', timestamp);
}

socket.on('btnPress', function(timestamp){
	var pTime = document.getElementById("timestamp");
	var curTimestamp = Date.now();
	pTime.append("\n\nButton pressed at: " + data.timestamp + "\nCurrent time is: " + curTimestamp);
});*/

var socket = io.connect("http://localhost:4000")

function btnPress() {
	console.log("button pressed");
	var timestamp = Date.now();
	console.log(timestamp);
	socket.emit('btnPress', timestamp);
	console.log("timestamp emited to server");
}

socket.on('btnPress', function(timestamp){
	console.log("client recieved timestamp: " + timestamp);
	var curTimestamp = Date.now();
	console.log("current timestamp: " + curTimestamp);
	document.getElementById("timestamp").innerHTML += "<br><br>Button pressed timestamp: " + timestamp + "<br>Current timestamp:  " + curTimestamp + "<br>Latency between button press and reception: " + (curTimestamp - timestamp) + " milliseconds.";
});